<template>
  <div class="dot-grid min-h-screen overflow-x-hidden">
    <BgCanvas />
    <AppNav />
    <main>
      <HeroSection />
      <MetricsSection />
      <ServicesSection />
      <WorkSection />
      <StackSection />
      <AboutSection />
      <ContactSection />
    </main>
    <AppFooter />
  </div>
</template>

<script setup lang="ts">
useHead({ htmlAttrs: { class: 'dark' } })

onMounted(() => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('active')
        observer.unobserve(e.target)
      }
    })
  }, { threshold: 0.15, rootMargin: '0px 0px -50px 0px' })

  document.querySelectorAll('.section-reveal').forEach(el => observer.observe(el))

  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault()
      const t = document.querySelector((a as HTMLAnchorElement).getAttribute('href') || '')
      t?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  })
})
</script>
