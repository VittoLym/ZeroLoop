<template>
  <div class="fixed inset-0 z-[-1] pointer-events-none">
    <canvas ref="canvas" class="w-full h-full" />
    <div class="absolute inset-0 bg-gradient-to-b from-[#050505] to-[#0a0a0a] -z-10" />
  </div>
</template>

<script setup lang="ts">
const canvas = ref<HTMLCanvasElement | null>(null)

onMounted(() => {
  const el = canvas.value
  if (!el) return
  const ctx = el.getContext('2d')
  if (!ctx) return

  let width = 0, height = 0
  let particles: { x: number; y: number; vx: number; vy: number; size: number }[] = []
  let raf: number

  function init() {
    width = el!.width = window.innerWidth
    height = el!.height = window.innerHeight
    particles = Array.from({ length: 60 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      size: Math.random() * 2 + 1,
    }))
  }

  function draw() {
    ctx!.clearRect(0, 0, width, height)
    ctx!.fillStyle = 'rgba(139,92,246,0.15)'
    ctx!.strokeStyle = 'rgba(139,92,246,0.05)'
    particles.forEach((p, i) => {
      p.x += p.vx; p.y += p.vy
      if (p.x < 0 || p.x > width) p.vx *= -1
      if (p.y < 0 || p.y > height) p.vy *= -1
      ctx!.beginPath(); ctx!.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx!.fill()
      for (let j = i + 1; j < particles.length; j++) {
        const d = Math.hypot(p.x - particles[j].x, p.y - particles[j].y)
        if (d < 200) {
          ctx!.globalAlpha = 1 - d / 200
          ctx!.beginPath(); ctx!.moveTo(p.x, p.y); ctx!.lineTo(particles[j].x, particles[j].y); ctx!.stroke()
          ctx!.globalAlpha = 1
        }
      }
    })
    raf = requestAnimationFrame(draw)
  }

  window.addEventListener('resize', init)
  init(); draw()
  onUnmounted(() => { cancelAnimationFrame(raf); window.removeEventListener('resize', init) })
})
</script>
